import './Provenmethod.css';
import provenimg from '../../../img/provenmethod1.jpg';
import provenimg2 from '../../../img/provenmethod2.jpg';
import provenimg3 from '../../../img/provenmethod3.jpg';

const Proventmethod =()=>{
    return(
        <>
        <section id="portfolio" class="portfolio">
            <div class="container" data-aos="fade-up">
            <div class="section-title">
                 <h2 className="provmethodtxt">Proven methods to derive guaranteed conversation</h2>
                <p className="prov-methodmagnam">Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea.</p>
            </div>

            <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">
                <div class="col-lg-4 col-md-4 col-sm-4"style={{marginTop:'3%'}}>
                    <div class="flip-card">
                        <div class="flip-card-inner">
                            <div class="flip-card-front">
                            <img src={provenimg} alt="Avatar" className="img-fluid"/>
                            </div>
                            <div class="flip-card-back">
                                <h3 style={{marginTop:'15%'}}>Proof of receipt for each interaction</h3>
                            </div>
                        </div>
                    </div>
                 </div>

                 <div class="col-lg-4 col-md-4 col-sm-4"style={{marginTop:'3%'}}>
                    <div class="flip-card">
                        <div class="flip-card-inner">
                            <div class="flip-card-front">
                            <img src={provenimg2} alt="Avatar" className="img-fluid"/>
                            </div>
                            <div class="flip-card-back">
                                <h3 style={{marginTop:'15%'}}>Real time delivery On Demand</h3>
                            </div>
                        </div>
                    </div>
                 </div>

                <div class="col-lg-4 col-md-4 col-sm-4"style={{marginTop:'3%'}}>
                    <div class="flip-card">
                        <div class="flip-card-inner">
                            <div class="flip-card-front">
                            <img src={provenimg3} alt="Avatar" className="img-fluid"/>
                            </div>
                            <div class="flip-card-back">
                                <h3 style={{marginTop:'15%'}}>2 level QA check to ensure 100% intent and contact details</h3>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-4 col-sm-4" style={{marginTop:'3%'}}>
                    <div class="flip-card">
                        <div class="flip-card-inner">
                            <div class="flip-card-front">
                            <img src={provenimg3} alt="Avatar" className="img-fluid"/>
                            </div>
                            <div class="flip-card-back">
                                <h3 style={{marginTop:'15%'}}>100% accurate contact details</h3>
                            </div>
                        </div>
                    </div>
                 </div>
            
                 <div class="col-lg-4 col-md-4 col-sm-4" style={{marginTop:'3%'}}>
                    <div class="flip-card">
                        <div class="flip-card-inner">
                            <div class="flip-card-front">
                            <img src={provenimg} alt="Avatar" className="img-fluid"/>
                            </div>
                            <div class="flip-card-back">
                                <h3 style={{marginTop:'15%'}}>Proof of receipt for each interaction</h3>
                            </div>
                        </div>
                    </div>
                 </div>

                <div class="col-lg-4 col-md-4 col-sm-4" style={{marginTop:'3%'}}>
                    <div class="flip-card">
                        <div class="flip-card-inner">
                            <div class="flip-card-front">
                            <img src={provenimg2} alt="Avatar" className="img-fluid"/>
                            </div>
                            <div class="flip-card-back">
                                <h3 style={{marginTop:'15%'}}>Proof of receipt for each interaction</h3>
                            </div>
                        </div>
                    </div>
                 </div>

            </div>
            </div>
        </section>

     

        </>
    )
}
export default Proventmethod;